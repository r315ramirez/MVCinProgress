<?php

// Assignation des variables
// Vérification de donnée en Get

	if(!isset($_GET['page']))
	{
		$_GET['page'] = 'page';
	}

?>
